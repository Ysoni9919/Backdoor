<!-- JAVASCRIPT -->
<script src="<?php echo base_url() ?>public/assets/libs/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ?>public/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>public/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?php echo base_url() ?>public/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo base_url() ?>public/assets/libs/node-waves/waves.min.js"></script>
<script src="<?php echo base_url() ?>public/assets/libs/feather-icons/feather.min.js"></script>
<!-- pace js -->
<script src="<?php echo base_url() ?>public/assets/libs/pace-js/pace.min.js"></script>