<!-- preloader css -->
<link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/preloader.min.css" type="text/css" />

<!-- Bootstrap Css -->
<link href="<?php echo base_url() ?>public/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo base_url() ?>public/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo base_url() ?>public/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />